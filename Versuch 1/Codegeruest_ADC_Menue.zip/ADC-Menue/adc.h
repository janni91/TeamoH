/*! \file
 *  \brief Analog digital converter module.
 *	Contains functionality to access the internal ADC of the microcontroller.
 *
 *  \author   Lehrstuhl f�r Informatik 11 - RWTH Aachen
 *  \date     2012
 *  \version  1.0
 */

#ifndef _ADC_H
#define _ADC_H

#include <stdint.h>

//! This method initializes the necessary registers for using the ADC module.
void initAdc(void);

//! Executes one conversion of the adc and returns its value.
uint16_t getAdcValue();

//! Returns the size of the buffer which stores voltage values.
uint16_t getBufferSize();

//! Returns the current index of the buffer which stores voltage values.
uint16_t getBufferIndex();

//! Stores the last captured voltage.
void storeVoltage(void);

//! Returns the voltage value with the passed index.
uint16_t getStoredVoltage(uint8_t ind);

#endif
