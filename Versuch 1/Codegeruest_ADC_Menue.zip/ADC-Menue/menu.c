#include "menu.h"
#include "os_input.h"
#include "bin_clock.h"
#include "lcd.h"
#include "led.h"
#include "adc.h"
#include <stdint.h>
#include <avr/io.h>


/*!
 *	Hello world program.
 *	Shows the string 'Hello World!' on the display.
 */
void helloWorld(void)
{
	// Repeat until ESC gets pressed
	#warning IMPLEMENT STH. HERE
}


/*!
 *	Shows the clock on the display and a binary clock on the led bar.
 */
void displayClock(void)
{
	#warning IMPLEMENT STH. HERE
}


/*!
 *	Shows the stored voltage values in the 2nd line of the display.
 */
void displayVoltageBuffer(uint8_t displayIndex)
{
	#warning IMPLEMENT STH. HERE
}


/*!
 *	Shows the adc value on the display and on the led bar.
 */
void displayAdc(void)
{
	#warning IMPLEMENT STH. HERE
}


/*! \brief Starts the passed program
 *
 * \param programIndex Index of the program to start.
 */
void start(uint8_t programIndex)
{
	// initialize and start the passed 'program'
	switch (programIndex)
	{
	case 0:
		lcd_clear();
		helloWorld();
		break;
	case 1:
		activateLedMask = 0xFFFF;	// use all leds
		initLedBar();
		initClock();
		displayClock();
		break;
	case 2:
		activateLedMask = 0xFFFE;	// don't use led 0
		initLedBar();
		initAdc();
		displayAdc();
		break;
	default:
		break;
	}

	// do not resume to the menu until all buttons are released
	os_waitForNoInput();
}


/*!
 *	Shows a user menu on the display which allows to start subprograms.
 */
void showMenu(void)
{
	uint8_t pageIndex = 0;

	while (1)
	{
		lcd_clear();
		lcd_progString(PSTR("Select:"));	
		lcd_line2();

		switch (pageIndex)
		{
		case 0:
			lcd_progString(PSTR("1: Hello world"));			
			break;
		case 1:
			lcd_progString(PSTR("2: Binary clock"));
			break;
		case 2:
			lcd_progString(PSTR("3: Internal ADC"));
			break;
		default:
			lcd_progString(PSTR("----------------"));
			break;
		}

		os_waitForInput();
		if (os_getInput() == 0b00000001)		// Enter
		{
			os_waitForNoInput();
			start(pageIndex);
		}
		else if (os_getInput() == 0b00000100)	// Up
		{
			os_waitForNoInput();
			pageIndex = (pageIndex + 1) % 3;
		}
		else if (os_getInput() == 0b00000010)	// Down
		{
			os_waitForNoInput();
			if (pageIndex == 0) 
			{
				pageIndex = 2; 
			}
			else 
			{
				pageIndex--;
			}
		}
	}
}
