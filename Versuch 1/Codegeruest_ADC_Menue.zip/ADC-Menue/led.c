#include "led.h"
#include <avr/io.h>

uint16_t activateLedMask = 0xFFFF;


/*
 *	Initializes the led bar. Note: All PORTs will be set to output.
 */
void initLedBar(void)
{
	#warning IMPLEMENT STH. HERE
}


/*
 *	Sets the passed value as states of the led bar (1 = on, 0 = off).
 */
void setLedBar(uint16_t value)
{
	#warning IMPLEMENT STH. HERE
}
