/*! \file
 *  \brief Button input library.
 *	Contains functionalities to read user input.
 *
 *  \author   Lehrstuhl f�r Informatik 11 - RWTH Aachen
 *  \date     2012
 *  \version  1.0
 */

#ifndef _OS_INPUT_H
#define _OS_INPUT_H

#include <stdint.h>

//----------------------------------------------------------------------------
// Function headers
//----------------------------------------------------------------------------

//! Initialises the respective Pins for the buttons, i.e. sets DDR and Pullups
void os_initInput(void);

//! Refreshes the button states
uint8_t os_getInput(void);

//! Waits for all buttons to be released
void os_waitForNoInput(void);

//! Waits for at least one button to be pressed
void os_waitForInput(void);

#endif
